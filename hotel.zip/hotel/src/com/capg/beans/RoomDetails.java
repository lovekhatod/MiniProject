package com.capg.beans;
public class RoomDetails {

	
	String hotel_id;
	String room_id;
	String room_no;
	String room_type;
	int per_night_rate;
	boolean availability;
	public RoomDetails(String hotel_id, String room_id, String room_no, String room_type, int per_night_rate,
			boolean availability) {
		super();
		this.hotel_id = hotel_id;
		this.room_id = room_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
	}
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}
	public String getRoom_id() {
		return room_id;
	}
	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}
	public String getRoom_no() {
		return room_no;
	}
	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public int getPer_night_rate() {
		return per_night_rate;
	}
	public void setPer_night_rate(int per_night_rate) {
		this.per_night_rate = per_night_rate;
	}
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}
	
	
	
	
}
