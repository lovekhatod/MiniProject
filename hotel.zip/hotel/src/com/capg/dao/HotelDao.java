package com.capg.dao;

import com.capg.beans.Users;
import com.capg.exception.HotelException;

public interface HotelDao {
	public String addUserDetails(Users users) throws HotelException;

}
