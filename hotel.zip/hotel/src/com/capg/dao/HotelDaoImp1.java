package com.capg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capg.beans.Users;
import com.capg.exception.HotelException;
import com.capgemini.donorapplication.dao.QueryMapper;
import com.capgemini.donorapplication.exception.DonorException;
import com.capgemini.donorapplication.util.DBConnection;

public class HotelDaoImp1 implements HotelDao{


	public String addUserDetails(Users users) throws HotelException {
        Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String user_id=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,donor.getDonorName());			
			preparedStatement.setString(2,donor.getAddress());
			preparedStatement.setString(3,donor.getPhoneNumber());
			preparedStatement.setDouble(4,donor.getDonationAmount());			
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.DONARID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				donorId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new DonorException("Inserting donor details failed ");

			}
			else
			{
				logger.info("Donor details added successfully:");
				return donorId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new DonorException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new DonorException("Error in closing db connection");

			}
		}
	}

}
