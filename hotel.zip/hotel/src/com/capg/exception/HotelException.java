package com.capg.exception;

public class HotelException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public HotelException(String message) 
	{
		
		super(message);
	}
}
