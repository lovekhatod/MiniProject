package com.capg.main;

import java.util.InputMismatchException;
import java.util.Scanner;



public class CustomerMain {
	
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args)
	{
		int option = 0;
		  
	  while(true)
	  {
		  
		  System.out.println("Hotel Bookings Managements Systenm\n");
		  System.out.println("________________________________\n");

			System.out.println("1.Sign up \n");
			System.out.println("2.Login\n");
			System.out.println("3.Exit\n");
			System.out.println("Enter your choice:");
		    try
		    {
		    	option = sc.nextInt();
		    	switch(option)
		    	{
		    	  case 1: 
		    		     break;
		    	  case 2: break;
		    	  case 3: break;
		    	  default:System.out.println("Enter a valid option[1-3]");
		    	  
		    	}
		    	
		    }
		    catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
			
	  }
	}
	
	
	
	
	
	
}




