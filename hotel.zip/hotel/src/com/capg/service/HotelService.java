package com.capg.service;

public interface HotelService {

}
