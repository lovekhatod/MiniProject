package com.capg.service;

public class HotelServiceImp1 {

}
